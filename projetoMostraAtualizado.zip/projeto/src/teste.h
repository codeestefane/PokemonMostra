#ifndef TESTE_H
#define TESTE_H

#include <time.h>
#include <raylib.h>
#include <stdbool.h>
#include "pokemon.h"
#include "global.h"
#include "backgroundMenu.h"

void mainMenu(Player* player);
void carregaMenu();
void descarregaMenu();


#endif