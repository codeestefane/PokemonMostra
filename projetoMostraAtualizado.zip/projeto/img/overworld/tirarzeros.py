import os

def rename_files_in_directory(directory):
    # Verifica se o diretório existe
    if not os.path.exists(directory):
        print(f"O diretório '{directory}' não existe.")
        return

    # Percorre todos os arquivos na pasta
    for filename in os.listdir(directory):
        filepath = os.path.join(directory, filename)

        # Verifica se o item é um arquivo
        if os.path.isfile(filepath):
            # Divide o nome do arquivo e a extensão
            name, ext = os.path.splitext(filename)

            # Verifica se o nome do arquivo consiste apenas de dígitos
            if name.isdigit():
                # Remove os zeros à esquerda e mantém pelo menos um zero se o nome for "0"
                new_name = str(int(name))
                new_filename = new_name + ext

                # Renomeia o arquivo
                os.rename(filepath, os.path.join(directory, new_filename))
                print(f"Arquivo renomeado: {filename} -> {new_filename}")

if __name__ == "__main__":
    current_directory = os.getcwd()
    rename_files_in_directory(current_directory)